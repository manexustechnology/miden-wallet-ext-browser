// Popup script for Miden Wallet Extension
// EXACTLY matching the webapp from app/page.tsx

console.log('Miden Wallet Extension Popup loaded - EXACT webapp match');

let walletData = null;
let isConnected = false;

// Create popup UI that EXACTLY matches the webapp
document.addEventListener('DOMContentLoaded', () => {
  const root = document.getElementById('root');
  if (root) {
    root.innerHTML = `
      <div class="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white">
        <!-- Connect Section (shown when no wallet) -->
        <div id="connectSection" class="flex items-center justify-center min-h-screen">
          <div class="text-center">
            <h1 class="text-4xl font-bold mb-6">Miden Web App</h1>
            <p class="mb-8 text-gray-300 text-lg">Create a new wallet or import an existing one to start using the Miden network</p>
            
            <div class="max-w-sm w-full bg-gray-800/20 border border-gray-600 rounded-2xl p-6 mx-auto">
              <div class="space-y-3">
                <button id="createWalletBtn" class="w-full px-6 py-3 text-lg cursor-pointer bg-orange-600 hover:bg-orange-700 text-white rounded-lg transition-all font-medium">
                  Create Miden Wallet & Faucet
                </button>
                
                <div class="relative">
                  <input type="file" id="importInput" accept=".json,.txt,.wallet,.backup" class="hidden" />
                  <label for="importInput" class="w-full px-6 py-3 text-lg cursor-pointer bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-all font-medium inline-block text-center">
                    Import Wallet
                  </label>
                </div>
              </div>
              
              <p class="text-sm text-gray-400 mt-4">
                Create a new account and deploy a faucet, or import an existing wallet backup
              </p>
            </div>
          </div>
        </div>
        
        <!-- Wallet Interface (shown when wallet is connected) -->
        <div id="walletInterface" class="hidden">
          <!-- Header -->
          <header class="bg-gray-800/50 border-b border-gray-600 p-4">
            <div class="max-w-6xl mx-auto flex items-center justify-between">
              <h1 class="text-2xl font-bold text-white">Miden Wallet</h1>
              <button id="disconnectBtn" class="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors">
                Disconnect
              </button>
            </div>
          </header>

          <div class="max-w-4xl mx-auto p-4">
            <!-- Top Card - Wallet Overview and Actions -->
            <div class="bg-gray-800/20 border border-gray-600 rounded-2xl p-6 mb-6">
              <!-- Wallet Address and Menu -->
              <div class="flex items-center justify-between mb-6">
                <div class="font-mono text-sm text-white">
                  <span id="walletAddress">Loading...</span>
                </div>
                <div class="relative">
                  <button id="menuBtn" class="w-8 h-8 bg-gray-700 hover:bg-gray-600 rounded-full flex items-center justify-center transition-colors">
                    <span class="text-white text-lg">⋮</span>
                  </button>
                  
                  <!-- Dropdown Menu -->
                  <div id="dropdownMenu" class="hidden absolute right-0 mt-2 w-48 bg-gray-800 border border-gray-600 rounded-lg shadow-lg z-50">
                    <div class="py-1">
                      <button class="w-full px-4 py-2 text-left text-white hover:bg-gray-700 flex items-center gap-3">
                        <span>⚙️</span>
                        <span>Wallet Settings</span>
                      </button>
                      
                      <button id="exportBtn" class="w-full px-4 py-2 text-left text-white hover:bg-gray-700 flex items-center gap-3">
                        <span>💾</span>
                        <span>Export Account</span>
                      </button>
                      
                      <label class="w-full px-4 py-2 text-left text-white hover:bg-gray-700 flex items-center gap-3 cursor-pointer">
                        <span>📁</span>
                        <span>Import Account</span>
                        <input type="file" accept=".json,.txt,.wallet,.backup" id="importWalletBtn" class="hidden" />
                      </label>
                      
                      <button class="w-full px-4 py-2 text-left text-red-400 hover:bg-gray-700 flex items-center gap-3">
                        <span>🗑️</span>
                        <span>Burn Wallet</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              <!-- Balance Display -->
              <div class="text-center mb-8">
                <div class="flex items-center justify-center gap-3 mb-2">
                  <div class="text-4xl font-bold text-white relative">
                    <span id="walletBalance">0</span>
                    <div id="balanceLoading" class="hidden absolute -top-1 -right-1 w-3 h-3 bg-orange-500 rounded-full animate-pulse"></div>
                  </div>
                  <button id="refreshBalanceBtn" class="p-2 rounded-full transition-colors bg-gray-700 hover:bg-gray-600" title="Refresh balance from blockchain">
                    <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                  </button>
                </div>
                <div class="text-lg text-white">MDN</div>
                <div class="text-xs text-gray-400 mt-1" id="balanceStatus">Live from blockchain</div>
              </div>
              
              <!-- Action Buttons -->
              <div class="grid grid-cols-4 gap-4">
                <button id="sendBtn" class="flex flex-col items-center p-4 rounded-full transition-all bg-orange-500 hover:bg-orange-600">
                  <svg class="w-6 h-6 text-white mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                  <span class="text-white text-sm">Send</span>
                </button>

                <button id="faucetBtn" class="flex flex-col items-center p-4 rounded-full transition-all bg-orange-500 hover:bg-orange-600">
                  <svg class="w-6 h-6 text-white mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                  </svg>
                  <span class="text-white text-sm">Faucet</span>
                </button>

                <button id="receiveBtn" class="flex flex-col items-center p-4 rounded-full transition-all bg-orange-500 hover:bg-orange-600">
                  <svg class="w-6 h-6 text-white mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V6a1 1 0 00-1-1H5a1 1 0 00-1 1v1a1 1 0 001 1zm12 0h2a1 1 0 001-1V6a1 1 0 00-1-1h-2a1 1 0 00-1 1v1a1 1 0 001 1zM5 20h2a1 1 0 001-1v-1a1 1 0 00-1-1H5a1 1 0 00-1 1v1a1 1 0 001 1z" />
                  </svg>
                  <span class="text-white text-sm">Receive</span>
                </button>

                <button id="activityBtn" class="flex flex-col items-center p-4 rounded-full transition-all bg-orange-500 hover:bg-orange-600">
                  <svg class="w-6 h-6 text-white mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                  <span class="text-white text-sm">Activity</span>
                </button>
              </div>
            </div>
            
            <!-- Bottom Card - Tab Content -->
            <div class="bg-gray-800/20 border border-gray-600 rounded-2xl p-6">
              <!-- Send Tab -->
              <div id="sendTab" class="hidden">
                <h2 class="text-xl font-bold text-white mb-6">Send Payment</h2>
                
                <!-- Amount Input -->
                <div class="mb-6">
                  <label class="block text-white text-sm font-medium mb-2">Amount</label>
                  <div class="flex items-center gap-3">
                    <input type="text" id="amountInput" placeholder="0.00" class="flex-1 bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400" />
                    <button id="maxAmountBtn" class="px-4 py-3 bg-orange-600 text-white rounded-lg font-medium">Max</button>
                  </div>
                </div>
                
                <!-- Recipient Input -->
                <div class="mb-6">
                  <label class="block text-white text-sm font-medium mb-2">Recipient</label>
                  <div class="flex items-center gap-3">
                    <input type="text" id="recipientInput" placeholder="0x..." class="flex-1 bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400" />
                    <button class="px-4 py-3 bg-gray-600 text-white rounded-lg">
                      <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                    </button>
                  </div>
                </div>

                <!-- Toggle Switches -->
                <div class="space-y-4 mb-6">
                  <div class="flex items-center justify-between">
                    <div>
                      <h3 class="text-white font-medium">One to Many Payment</h3>
                      <p class="text-gray-400 text-sm">Send to multiple recipients</p>
                    </div>
                    <div class="w-12 h-6 bg-gray-600 rounded-full relative">
                      <div class="w-5 h-5 bg-gray-400 rounded-full absolute left-0.5 top-0.5"></div>
                    </div>
                  </div>

                  <div class="flex items-center justify-between">
                    <div>
                      <h3 class="text-white font-medium">Private Payment</h3>
                      <p class="text-gray-400 text-sm">Keep transaction details private</p>
                    </div>
                    <div class="w-12 h-6 bg-gray-600 rounded-full relative">
                      <div class="w-5 h-5 bg-gray-400 rounded-full absolute left-0.5 top-0.5"></div>
                    </div>
                  </div>
                </div>
                
                <!-- Checkbox -->
                <div class="flex items-center gap-3 mb-6">
                  <input type="checkbox" id="delegateProving" class="w-5 h-5 text-orange-600 bg-gray-700 border-gray-600 rounded" />
                  <label class="text-white">Use Delegate Proving</label>
                  <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>

                <!-- Send Button -->
                <button class="w-full bg-orange-600 text-white py-4 rounded-lg font-medium text-lg opacity-75">Send Payment</button>
              </div>
              
              <!-- Faucet Tab -->
              <div id="faucetTab" class="hidden">
                <h2 class="text-xl font-bold text-white mb-6">Mint from Faucet</h2>
                
                <!-- Amount Selection -->
                <div class="mb-6">
                  <label class="block text-white text-sm font-medium mb-2">Amount</label>
                  <div class="flex gap-2 mb-3">
                    <button class="px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm hover:bg-gray-600">100</button>
                    <button class="px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm hover:bg-gray-600">500</button>
                    <button class="px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm hover:bg-gray-600">1000</button>
                  </div>
                  <input type="text" id="mintAmountInput" value="500" placeholder="0.00" class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400" />
                </div>
                
                <!-- Mint Button -->
                <button id="mintBtn" class="w-full bg-orange-600 text-white py-4 rounded-lg font-medium text-lg hover:bg-orange-700">Mint</button>

                <!-- Network Info -->
                <div class="mt-6 p-4 bg-gray-700/30 rounded-lg border border-gray-600">
                  <div class="flex items-center justify-between text-sm">
                    <span class="text-gray-400">Network:</span>
                    <span class="text-white">Miden Testnet</span>
                  </div>
                  <div class="flex items-center justify-between text-sm mt-2">
                    <span class="text-gray-400">Block:</span>
                    <span class="text-white" id="blockNumber">Loading...</span>
                  </div>
                </div>

                <!-- Error Information -->
                <div class="mt-4 p-4 bg-yellow-900/20 border border-yellow-600/50 rounded-lg">
                  <h4 class="font-semibold text-yellow-400 mb-2">⚠️ Faucet Information</h4>
                  <div class="text-sm text-yellow-300 space-y-1">
                    <div>Faucet ID: <span id="faucetAddress">Loading...</span></div>
                    <div>Current Balance: <span id="faucetBalance">Loading...</span> MID</div>
                    <div class="text-yellow-200 mt-2">
                      <strong>Note:</strong> This faucet may have limitations. If you encounter "P2IDE reclaim is disabled" errors, 
                      the faucet requires reclaim functionality which may not be enabled on this testnet node.
                    </div>
                    <div class="text-yellow-200 mt-1">
                      <strong>Solution:</strong> Try using a different faucet or wait for the node to enable reclaim functionality.
                    </div>
                  </div>
                </div>
              </div>

              <!-- Receive Tab -->
              <div id="receiveTab" class="hidden text-center">
                <h2 class="text-xl font-bold text-white mb-6">Receive MID</h2>
                
                <!-- QR Code -->
                <div class="flex justify-center mb-6">
                  <div class="w-48 h-48 bg-white rounded-lg flex items-center justify-center">
                    <div class="text-center text-gray-600">
                      <svg class="w-24 h-24 mx-auto mb-2" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M3 4a1 1 0 011-1h3a1 1 0 011 1v3a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 16a1 1 0 011-1h3a1 1 0 011 1v3a1 1 0 01-1 1H4a1 1 0 01-1-1v-3zM16 3a1 1 0 011-1h3a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1V3zM16 16a1 1 0 011-1h3a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-3z"/>
                      </svg>
                      <p class="text-sm">QR Code</p>
                    </div>
                  </div>
                </div>
                
                <!-- Miden Address -->
                <div class="bg-gray-700/50 rounded-lg border border-orange-500/50 p-4">
                  <p class="text-gray-400 text-sm mb-2">Your Miden Address</p>
                  <div class="flex items-center justify-between bg-gray-800/50 rounded p-3">
                    <span class="font-mono text-sm text-white break-all mr-2" id="receiveAddress">Loading...</span>
                    <button id="copyAddressBtn" class="flex-shrink-0 p-2 bg-orange-600 hover:bg-orange-500 rounded transition-colors" title="Copy Miden address">
                      <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                      </svg>
                    </button>
                  </div>
                  <p class="text-gray-400 text-xs mt-2">
                    Share this address to receive MID tokens
                  </p>
                </div>
              </div>

              <!-- Activity Tab -->
              <div id="activityTab" class="hidden">
                <h2 class="text-xl font-bold text-white mb-6">Recent Activity</h2>
                
                <!-- Transaction History -->
                <div class="space-y-4">
                  <div class="bg-gray-700/30 p-4 rounded-lg border border-gray-600">
                    <div class="flex items-center justify-between">
                      <div class="flex items-center gap-3">
                        <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                          <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 11l5-5m0 0l5 5m-5-5v12" />
                          </svg>
                        </div>
                        <div>
                          <p class="text-white font-medium">Received</p>
                          <p class="text-gray-400 text-sm"># 437789</p>
                        </div>
                      </div>
                      <span class="text-green-400 font-medium">+$1k</span>
                    </div>
                  </div>
                  
                  <div class="bg-gray-700/30 p-4 rounded-lg border border-gray-600">
                    <div class="flex items-center justify-between">
                      <div class="flex items-center gap-3">
                        <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                          <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 11l5-5m0 0l5 5m-5-5v12" />
                          </svg>
                        </div>
                        <div>
                          <p class="text-white font-medium">Received</p>
                          <p class="text-gray-400 text-sm"># 386588</p>
                        </div>
                      </div>
                      <span class="text-green-400 font-medium">+$1k</span>
                    </div>
                  </div>
                </div>

                <!-- No More Transactions Message -->
                <div class="text-center mt-6">
                  <p class="text-gray-400 text-sm">No more transactions to show</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    
    setupEventListeners();
    checkWalletStatus();
  }
});

function setupEventListeners() {
  // Connect section buttons
  const createWalletBtn = document.getElementById('createWalletBtn');
  const importInput = document.getElementById('importInput');
  
  // Wallet interface buttons
  const disconnectBtn = document.getElementById('disconnectBtn');
  const refreshBalanceBtn = document.getElementById('refreshBalanceBtn');
  const sendBtn = document.getElementById('sendBtn');
  const faucetBtn = document.getElementById('faucetBtn');
  const receiveBtn = document.getElementById('receiveBtn');
  const activityBtn = document.getElementById('activityBtn');
  
  // Menu and dropdown
  const menuBtn = document.getElementById('menuBtn');
  const dropdownMenu = document.getElementById('dropdownMenu');
  const exportBtn = document.getElementById('exportBtn');
  const importWalletBtn = document.getElementById('importWalletBtn');
  
  // Form elements
  const amountInput = document.getElementById('amountInput');
  const recipientInput = document.getElementById('recipientInput');
  const maxAmountBtn = document.getElementById('maxAmountBtn');
  const mintAmountInput = document.getElementById('mintAmountInput');
  const mintBtn = document.getElementById('mintBtn');
  const copyAddressBtn = document.getElementById('copyAddressBtn');
  
  // Event listeners
  if (createWalletBtn) createWalletBtn.addEventListener('click', handleCreateWallet);
  if (importInput) importInput.addEventListener('change', handleImportWallet);
  
  if (disconnectBtn) disconnectBtn.addEventListener('click', handleDisconnect);
  if (refreshBalanceBtn) refreshBalanceBtn.addEventListener('click', handleRefreshBalance);
  if (faucetBtn) faucetBtn.addEventListener('click', handleFaucet);
  if (sendBtn) sendBtn.addEventListener('click', () => showTab('send'));
  if (receiveBtn) receiveBtn.addEventListener('click', () => showTab('receive'));
  if (activityBtn) activityBtn.addEventListener('click', () => showTab('activity'));
  
  if (menuBtn) menuBtn.addEventListener('click', () => toggleDropdown());
  if (exportBtn) exportBtn.addEventListener('click', handleExportWallet);
  if (importWalletBtn) importWalletBtn.addEventListener('change', handleImportWallet);
  
  if (maxAmountBtn) maxAmountBtn.addEventListener('click', handleMaxAmount);
  if (mintBtn) mintBtn.addEventListener('click', handleMint);
  if (copyAddressBtn) copyAddressBtn.addEventListener('click', handleCopyAddress);
  
  // Close dropdown when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#menuBtn') && !e.target.closest('#dropdownMenu')) {
      dropdownMenu?.classList.add('hidden');
    }
  });
}

async function checkWalletStatus() {
  try {
    const result = await chrome.storage.local.get(['miden-wallet-data', 'miden-connection-status']);
    const wallet = result['miden-wallet-data'];
    const connectionStatus = result['miden-connection-status'];
    
    if (wallet && connectionStatus === 'connected') {
      walletData = wallet;
      isConnected = true;
      showWalletInterface();
      updateWalletDisplay();
    } else {
      showConnectSection();
    }
  } catch (error) {
    console.error('Failed to check wallet status:', error);
    showConnectSection();
  }
}

async function handleCreateWallet() {
  try {
    // Call background script to create REAL Miden wallet using webapp functions
    const response = await chrome.runtime.sendMessage({
      type: 'CREATE_REAL_MIDEN_WALLET_WEBAPP'
    });
    
    if (response.success) {
      walletData = response.wallet;
      isConnected = true;
      
      // Save to storage
      await chrome.storage.local.set({
        'miden-wallet-data': walletData,
        'miden-connection-status': 'connected'
      });
      
      showWalletInterface();
      updateWalletDisplay();
      
      alert('REAL Miden wallet created successfully using webapp functions!');
    } else {
      throw new Error(response.error || 'Failed to create wallet');
    }
    
  } catch (error) {
    console.error('Failed to create wallet:', error);
    alert(`Failed to create wallet: ${error.message}`);
  }
}

async function handleImportWallet(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  
  try {
    const text = await file.text();
    const parsedData = JSON.parse(text);
    
    let wallet = null;
    if (parsedData.walletInfo) {
      wallet = parsedData.walletInfo;
    } else if (parsedData.aliceId || parsedData.faucetId) {
      wallet = parsedData;
    }
    
    if (wallet) {
      await chrome.storage.local.set({
        'miden-wallet-data': wallet,
        'miden-connection-status': 'connected'
      });
      
      walletData = wallet;
      isConnected = true;
      
      showWalletInterface();
      updateWalletDisplay();
      
      alert('Wallet imported successfully!');
    } else {
      alert('Invalid wallet file format');
    }
    
    // Reset input
    const importInput = document.getElementById('importInput');
    if (importInput) {
      importInput.value = '';
    }
    
  } catch (error) {
    console.error('Failed to import wallet:', error);
    alert('Failed to import wallet');
  }
}

async function handleDisconnect() {
  try {
    await chrome.storage.local.remove(['miden-wallet-data', 'miden-connection-status']);
    
    walletData = null;
    isConnected = false;
    
    showConnectSection();
    alert('Wallet disconnected successfully');
    
  } catch (error) {
    console.error('Failed to disconnect wallet:', error);
    alert('Failed to disconnect wallet');
  }
}

async function handleRefreshBalance() {
  if (!walletData) return;
  
  try {
    const balanceLoading = document.getElementById('balanceLoading');
    const balanceStatus = document.getElementById('balanceStatus');
    
    if (balanceLoading) balanceLoading.classList.remove('hidden');
    if (balanceStatus) balanceStatus.textContent = 'Updating from blockchain...';
    
    // Call background script to get REAL-TIME balance using webapp functions
    const response = await chrome.runtime.sendMessage({
      type: 'GET_REAL_TIME_BALANCE_WEBAPP',
      accountId: walletData.aliceId
    });
    
    if (response.success) {
      walletData.aliceBalance = response.balance;
      if (response.notes) {
        walletData.mintedNotes = response.notes;
      }
      
      await chrome.storage.local.set({
        'miden-wallet-data': walletData
      });
      
      updateWalletDisplay();
      alert(`Balance refreshed from blockchain! Current balance: ${response.balance} MDN`);
    } else {
      throw new Error(response.error || 'Failed to refresh balance');
    }
    
  } catch (error) {
    console.error('Failed to refresh balance:', error);
    alert(`Failed to refresh balance: ${error.message}`);
  } finally {
    const balanceLoading = document.getElementById('balanceLoading');
    const balanceStatus = document.getElementById('balanceStatus');
    
    if (balanceLoading) balanceLoading.classList.add('hidden');
    if (balanceStatus) balanceStatus.textContent = 'Live from blockchain';
  }
}

async function handleFaucet() {
  if (!walletData) return;
  
  try {
    showTab('faucet');
    alert('Faucet tab opened');
  } catch (error) {
    console.error('Failed to open faucet tab:', error);
    alert('Failed to open faucet tab');
  }
}

async function handleMint() {
  if (!walletData) return;
  
  try {
    const mintAmount = document.getElementById('mintAmountInput')?.value || '500';
    
    alert(`Minting ${mintAmount} tokens from REAL faucet...`);
    
    // Call background script to mint from REAL faucet using webapp functions
    const response = await chrome.runtime.sendMessage({
      type: 'MINT_FROM_FAUCET_WEBAPP',
      amount: mintAmount,
      faucetId: walletData.faucetId,
      accountId: walletData.aliceId
    });
    
    if (response.success) {
      walletData.aliceBalance = response.newBalance;
      
      await chrome.storage.local.set({
        'miden-wallet-data': walletData
      });
      
      updateWalletDisplay();
      alert(`Successfully minted ${mintAmount} tokens from REAL faucet! New balance: ${response.newBalance} MDN`);
    } else {
      throw new Error(response.error || 'Failed to mint tokens');
    }
    
  } catch (error) {
    console.error('Failed to mint tokens:', error);
    alert(`Failed to mint tokens: ${error.message}`);
  }
}

function handleMaxAmount() {
  if (walletData && walletData.aliceBalance) {
    const amountInput = document.getElementById('amountInput');
    if (amountInput) {
      amountInput.value = walletData.aliceBalance;
    }
  }
}

async function handleCopyAddress() {
  if (walletData && walletData.aliceMidenAddress) {
    try {
      await navigator.clipboard.writeText(walletData.aliceMidenAddress);
      alert('Miden address copied to clipboard!');
    } catch (error) {
      console.error('Failed to copy address:', error);
      alert('Failed to copy address');
    }
  }
}

async function handleExportWallet() {
  if (!walletData) return;
  
  try {
    alert('Exporting wallet...');
    
    // Create export data matching webapp format
    const exportData = {
      timestamp: new Date().toISOString(),
      walletInfo: walletData,
      message: "Miden Wallet Backup Export",
      version: "1.0",
      exportType: "wallet-backup",
      source: "Miden Wallet Extension"
    };
    
    // Convert to JSON and download
    const jsonString = JSON.stringify(exportData, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `miden-wallet-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    alert('Wallet exported successfully!');
    
  } catch (error) {
    console.error('Failed to export wallet:', error);
    alert('Failed to export wallet');
  }
}

function toggleDropdown() {
  const dropdownMenu = document.getElementById('dropdownMenu');
  if (dropdownMenu) {
    dropdownMenu.classList.toggle('hidden');
  }
}

function showTab(tabName) {
  // Hide all tabs
  const tabs = ['sendTab', 'faucetTab', 'receiveTab', 'activityTab'];
  tabs.forEach(tab => {
    const tabElement = document.getElementById(tab);
    if (tabElement) tabElement.classList.add('hidden');
  });
  
  // Show selected tab
  const selectedTab = document.getElementById(tabName + 'Tab');
  if (selectedTab) selectedTab.classList.remove('hidden');
  
  // Update active button state
  const buttons = ['sendBtn', 'faucetBtn', 'receiveBtn', 'activityBtn'];
  buttons.forEach(btn => {
    const buttonElement = document.getElementById(btn);
    if (buttonElement) {
      buttonElement.classList.remove('bg-orange-600', 'scale-110');
      buttonElement.classList.add('bg-orange-500');
    }
  });
  
  const activeButton = document.getElementById(tabName + 'Btn');
  if (activeButton) {
    activeButton.classList.remove('bg-orange-500');
    activeButton.classList.add('bg-orange-600', 'scale-110');
  }
}

function showConnectSection() {
  const connectSection = document.getElementById('connectSection');
  const walletInterface = document.getElementById('walletInterface');
  
  if (connectSection) connectSection.classList.remove('hidden');
  if (walletInterface) walletInterface.classList.add('hidden');
}

function showWalletInterface() {
  const connectSection = document.getElementById('connectSection');
  const walletInterface = document.getElementById('walletInterface');
  
  if (connectSection) connectSection.classList.add('hidden');
  if (walletInterface) walletInterface.classList.remove('hidden');
  
  // Show send tab by default
  showTab('send');
}

function updateWalletDisplay() {
  if (!walletData) return;
  
  const walletAddress = document.getElementById('walletAddress');
  const walletBalance = document.getElementById('walletBalance');
  const blockNumber = document.getElementById('blockNumber');
  const faucetAddress = document.getElementById('faucetAddress');
  const faucetBalance = document.getElementById('faucetBalance');
  const receiveAddress = document.getElementById('receiveAddress');
  
  if (walletAddress) {
    const address = walletData.aliceMidenAddress || walletData.aliceId || 'Loading...';
    if (address.length > 12) {
      walletAddress.textContent = `${address.slice(0, 8)}...${address.slice(-4)}`;
    } else {
      walletAddress.textContent = address;
    }
  }
  
  if (walletBalance) {
    walletBalance.textContent = walletData.aliceBalance || '0';
  }
  
  if (blockNumber) {
    blockNumber.textContent = walletData.blockNumber?.toString() || 'Loading...';
  }
  
  if (faucetAddress) {
    faucetAddress.textContent = walletData.faucetMidenAddress || 'Loading...';
  }
  
  if (faucetBalance) {
    faucetBalance.textContent = walletData.aliceBalance || '0';
  }
  
  if (receiveAddress) {
    receiveAddress.textContent = walletData.aliceMidenAddress || 'Loading...';
  }
}
