// Content script for Miden Wallet Extension
// Integrated with webapp functionality

console.log('Miden Wallet Content Script loaded');

// Wallet state
let walletData = null;
let isConnected = false;

// Listen for messages from background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Content script received message:', request);
  
  switch (request.type) {
    case 'STORAGE_CHANGED':
      handleStorageChanged(request.changes);
      break;
      
    case 'GET_PAGE_INFO':
      handleGetPageInfo(sendResponse);
      return true;
      
    case 'INJECT_WALLET_UI':
      injectWalletUI();
      break;
      
    default:
      console.log('Unknown message type:', request.type);
  }
});

// Handle storage changes
function handleStorageChanged(changes) {
  console.log('Storage changed in content script:', changes);
  
  // Check if wallet data changed
  if (changes['miden-wallet-data']) {
    console.log('Wallet data updated');
    walletData = changes['miden-wallet-data'].newValue;
    isConnected = !!walletData;
    
    // Update UI if wallet UI is injected
    updateWalletUI();
  }
  
  // Check if connection status changed
  if (changes['miden-connection-status']) {
    console.log('Connection status updated');
    isConnected = changes['miden-connection-status'].newValue === 'connected';
    
    if (!isConnected) {
      walletData = null;
      removeWalletUI();
    }
  }
}

// Handle page info requests
function handleGetPageInfo(sendResponse) {
  const pageInfo = {
    url: window.location.href,
    title: document.title,
    domain: window.location.hostname,
    timestamp: Date.now(),
    hasWallet: isConnected,
    walletData: walletData
  };
  
  sendResponse({ success: true, pageInfo });
}

// Inject wallet connection button into pages
function injectWalletUI() {
  // Only inject on specific pages if needed
  if (window.location.hostname.includes('miden') || 
      window.location.hostname.includes('localhost') || 
      window.location.hostname.includes('127.0.0.1')) {
    
    // Check if wallet UI is already injected
    if (document.getElementById('miden-wallet-extension-ui')) {
      return;
    }
    
    console.log('Injecting Miden Wallet UI into page');
    
    // Create wallet UI container
    const walletContainer = document.createElement('div');
    walletContainer.id = 'miden-wallet-extension-ui';
    walletContainer.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 10000;
      background: rgba(59, 130, 246, 0.95);
      backdrop-filter: blur(10px);
      color: white;
      border-radius: 12px;
      padding: 16px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      min-width: 280px;
      transition: all 0.3s ease;
    `;
    
    // Create wallet UI content
    walletContainer.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
        <h3 style="margin: 0; font-size: 16px; font-weight: 600;">🔐 Miden Wallet</h3>
        <button id="miden-wallet-close" style="background: none; border: none; color: white; cursor: pointer; font-size: 18px;">×</button>
      </div>
      
      <div id="miden-wallet-content">
        <div id="miden-wallet-connect" style="text-align: center;">
          <p style="margin: 0 0 12px 0; font-size: 14px; opacity: 0.9;">Connect your Miden wallet to use this page</p>
          <button id="miden-wallet-connect-btn" style="
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
            color: white;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.2s ease;
          ">Connect Wallet</button>
        </div>
        
        <div id="miden-wallet-info" style="display: none;">
          <div style="margin-bottom: 12px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
              <span style="font-size: 12px; opacity: 0.8;">Address:</span>
              <span id="miden-wallet-address" style="font-family: monospace; font-size: 11px;">Loading...</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
              <span style="font-size: 12px; opacity: 0.8;">Balance:</span>
              <span id="miden-wallet-balance" style="font-weight: 600; color: #10b981;">0 MDN</span>
            </div>
          </div>
          
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 12px;">
            <button id="miden-wallet-mint" style="
              background: rgba(16, 185, 129, 0.8);
              border: none;
              color: white;
              padding: 6px 12px;
              border-radius: 6px;
              cursor: pointer;
              font-size: 12px;
              transition: all 0.2s ease;
            ">🪙 Mint</button>
            
            <button id="miden-wallet-refresh" style="
              background: rgba(59, 130, 246, 0.8);
              border: none;
              color: white;
              padding: 6px 12px;
              border-radius: 6px;
              cursor: pointer;
              font-size: 12px;
              transition: all 0.2s ease;
            ">🔄 Refresh</button>
          </div>
          
          <button id="miden-wallet-disconnect" style="
            background: rgba(239, 68, 68, 0.8);
            border: none;
            color: white;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 12px;
            width: 100%;
            transition: all 0.2s ease;
          ">Disconnect</button>
        </div>
      </div>
    `;
    
    // Add to page
    document.body.appendChild(walletContainer);
    
    // Add event listeners
    setupWalletUIEvents();
    
    // Update UI based on current wallet state
    updateWalletUI();
  }
}

// Setup wallet UI event listeners
function setupWalletUIEvents() {
  const connectBtn = document.getElementById('miden-wallet-connect-btn');
  const disconnectBtn = document.getElementById('miden-wallet-disconnect');
  const mintBtn = document.getElementById('miden-wallet-mint');
  const refreshBtn = document.getElementById('miden-wallet-refresh');
  const closeBtn = document.getElementById('miden-wallet-close');
  
  if (connectBtn) {
    connectBtn.addEventListener('click', handleConnectFromPage);
  }
  
  if (disconnectBtn) {
    disconnectBtn.addEventListener('click', handleDisconnectFromPage);
  }
  
  if (mintBtn) {
    mintBtn.addEventListener('click', handleMintFromPage);
  }
  
  if (refreshBtn) {
    refreshBtn.addEventListener('click', handleRefreshFromPage);
  }
  
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      const container = document.getElementById('miden-wallet-extension-ui');
      if (container) {
        container.style.display = 'none';
      }
    });
  }
}

// Handle connect from page
async function handleConnectFromPage() {
  try {
    // Open extension popup
    chrome.runtime.sendMessage({ type: 'OPEN_POPUP' });
    
    // Or show a message to use the extension popup
    showPageToast('Please use the Miden Wallet extension popup to connect your wallet', 'info');
    
  } catch (error) {
    console.error('Failed to connect from page:', error);
    showPageToast('Failed to connect wallet', 'error');
  }
}

// Handle disconnect from page
async function handleDisconnectFromPage() {
  try {
    // Clear wallet data
    await chrome.storage.local.remove(['miden-wallet-data', 'miden-connection-status']);
    
    walletData = null;
    isConnected = false;
    
    updateWalletUI();
    showPageToast('Wallet disconnected', 'success');
    
  } catch (error) {
    console.error('Failed to disconnect from page:', error);
    showPageToast('Failed to disconnect wallet', 'error');
  }
}

// Handle mint from page
async function handleMintFromPage() {
  if (!walletData) return;
  
  try {
    const mintBtn = document.getElementById('miden-wallet-mint');
    if (mintBtn) {
      mintBtn.textContent = '🔄 Minting...';
      mintBtn.disabled = true;
    }
    
    // Send mint request to background script
    const response = await chrome.runtime.sendMessage({
      type: 'MINT_TOKENS',
      amount: '500',
      faucetId: walletData.faucetId,
      accountId: walletData.aliceId
    });
    
    if (response.success) {
      showPageToast(`Successfully minted 500 tokens! New balance: ${response.newBalance} MDN`, 'success');
      
      // Update local wallet data
      walletData.aliceBalance = response.newBalance;
      updateWalletUI();
    } else {
      showPageToast(`Failed to mint tokens: ${response.error}`, 'error');
    }
    
    // Reset button
    if (mintBtn) {
      mintBtn.textContent = '🪙 Mint';
      mintBtn.disabled = false;
    }
    
  } catch (error) {
    console.error('Failed to mint from page:', error);
    showPageToast('Failed to mint tokens', 'error');
    
    // Reset button
    const mintBtn = document.getElementById('miden-wallet-mint');
    if (mintBtn) {
      mintBtn.textContent = '🪙 Mint';
      mintBtn.disabled = false;
    }
  }
}

// Handle refresh from page
async function handleRefreshFromPage() {
  if (!walletData) return;
  
  try {
    const refreshBtn = document.getElementById('miden-wallet-refresh');
    if (refreshBtn) {
      refreshBtn.textContent = '🔄 Refreshing...';
      refreshBtn.disabled = true;
    }
    
    // Send refresh request to background script
    const response = await chrome.runtime.sendMessage({
      type: 'GET_BALANCE',
      accountId: walletData.aliceId
    });
    
    if (response.success) {
      walletData.aliceBalance = response.balance;
      updateWalletUI();
      showPageToast('Balance refreshed!', 'success');
    } else {
      showPageToast(`Failed to refresh balance: ${response.error}`, 'error');
    }
    
    // Reset button
    if (refreshBtn) {
      refreshBtn.textContent = '🔄 Refresh';
      refreshBtn.disabled = false;
    }
    
  } catch (error) {
    console.error('Failed to refresh from page:', error);
    showPageToast('Failed to refresh balance', 'error');
    
    // Reset button
    const refreshBtn = document.getElementById('miden-wallet-refresh');
    if (refreshBtn) {
      refreshBtn.textContent = '🔄 Refresh';
      refreshBtn.disabled = false;
    }
  }
}

// Update wallet UI based on current state
function updateWalletUI() {
  const connectSection = document.getElementById('miden-wallet-connect');
  const infoSection = document.getElementById('miden-wallet-info');
  const addressEl = document.getElementById('miden-wallet-address');
  const balanceEl = document.getElementById('miden-wallet-balance');
  
  if (isConnected && walletData) {
    // Show wallet info
    if (connectSection) connectSection.style.display = 'none';
    if (infoSection) infoSection.style.display = 'block';
    
    // Update address and balance
    if (addressEl) {
      const address = walletData.aliceMidenAddress || walletData.aliceId || 'Unknown';
      addressEl.textContent = address.length > 20 ? 
        address.slice(0, 10) + '...' + address.slice(-8) : address;
    }
    
    if (balanceEl) {
      balanceEl.textContent = `${walletData.aliceBalance || '0'} MDN`;
    }
  } else {
    // Show connect section
    if (connectSection) connectSection.style.display = 'block';
    if (infoSection) infoSection.style.display = 'none';
  }
}

// Remove wallet UI
function removeWalletUI() {
  const container = document.getElementById('miden-wallet-extension-ui');
  if (container) {
    container.remove();
  }
}

// Show toast notification on page
function showPageToast(message, type = 'info') {
  // Create toast element
  const toast = document.createElement('div');
  toast.style.cssText = `
    position: fixed;
    top: 80px;
    right: 20px;
    z-index: 10001;
    padding: 12px 16px;
    border-radius: 8px;
    color: white;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    max-width: 300px;
    word-wrap: break-word;
    ${type === 'success' ? 'background: #10b981;' :
      type === 'error' ? 'background: #ef4444;' :
      type === 'warning' ? 'background: #f59e0b;' : 'background: #3b82f6;'}
  `;
  
  toast.textContent = message;
  
  // Add to page
  document.body.appendChild(toast);
  
  // Auto-remove after 4 seconds
  setTimeout(() => {
    if (document.body.contains(toast)) {
      document.body.removeChild(toast);
    }
  }, 4000);
}

// Initialize content script
document.addEventListener('DOMContentLoaded', () => {
  console.log('DOM loaded, initializing Miden Wallet content script');
  
  // Check current wallet status
  checkWalletStatus();
  
  // Inject wallet UI if appropriate
  setTimeout(() => {
    injectWalletUI();
  }, 1000);
});

// Check wallet status on load
async function checkWalletStatus() {
  try {
    const result = await chrome.storage.local.get(['miden-wallet-data', 'miden-connection-status']);
    const wallet = result['miden-wallet-data'];
    const connectionStatus = result['miden-connection-status'];
    
    if (wallet && connectionStatus === 'connected') {
      walletData = wallet;
      isConnected = true;
    }
  } catch (error) {
    console.error('Failed to check wallet status:', error);
  }
}

// Listen for page navigation (for SPA support)
let currentUrl = window.location.href;
const observer = new MutationObserver(() => {
  if (currentUrl !== window.location.href) {
    currentUrl = window.location.href;
    console.log('Page navigated to:', currentUrl);
    
    // Re-inject wallet UI after navigation
    setTimeout(() => {
      injectWalletUI();
    }, 1000);
  }
});

// Only observe if document.body exists
if (document.body) {
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}
